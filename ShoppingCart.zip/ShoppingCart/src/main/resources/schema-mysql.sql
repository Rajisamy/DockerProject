
CREATE TABLE IF NOT EXISTS product (
  productId VARCHAR(10) NOT NULL,
  productName VARCHAR(100) NOT NULL
);

