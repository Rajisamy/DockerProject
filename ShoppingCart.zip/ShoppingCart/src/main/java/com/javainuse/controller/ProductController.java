package com.javainuse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Product;
import com.javainuse.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService prodService;

	@RequestMapping(value = "/getProducts", method = RequestMethod.GET)
	public List<Product> getProduct() {

		return prodService.getAllProducts();

	}
	
	@RequestMapping(value = "/addProducts", method = RequestMethod.POST)
	public void addProduct(@RequestBody Product product) {
		prodService.addProduct(product);
	}

}
