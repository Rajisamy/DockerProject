package com.javainuse.service;

import java.util.List;

import com.javainuse.model.Product;

public interface ProductService {
	List<Product> getAllProducts();
	void addProduct(Product employee);
}