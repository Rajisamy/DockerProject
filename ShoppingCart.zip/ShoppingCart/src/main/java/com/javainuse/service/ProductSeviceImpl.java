package com.javainuse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javainuse.dao.ProductDao;
import com.javainuse.model.Product;

@Service
public class ProductSeviceImpl implements ProductService {

	@Autowired
	ProductDao productDao;

	public List<Product> getAllProducts() {
		List<Product> products = productDao.getAllProducts();
		return products;
	}

	@Override
	public void addProduct(Product product) {
		productDao.addProduct(product);
		
	}

}