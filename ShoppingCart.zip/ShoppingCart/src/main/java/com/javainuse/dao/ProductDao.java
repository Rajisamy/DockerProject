package com.javainuse.dao;

import java.util.List;

import com.javainuse.model.Product;

public interface ProductDao {
	List<Product> getAllProducts();

	void addProduct(Product product);
}