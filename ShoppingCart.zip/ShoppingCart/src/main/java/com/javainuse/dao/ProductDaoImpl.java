package com.javainuse.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.javainuse.model.Product;

@Repository
public class ProductDaoImpl extends JdbcDaoSupport implements ProductDao {

	@Autowired
	DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public List<Product> getAllProducts() {
		String sql = "SELECT * FROM product";
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);

		List<Product> result = new ArrayList<Product>();
		for (Map<String, Object> row : rows) {
			Product pro = new Product();
			pro.setProductId((String) row.get("productId"));
			pro.setProductName((String) row.get("productName"));
			result.add(pro);
		}

		return result;
	}

	@Override
	public void addProduct(Product product) {
		String sql = "INSERT INTO product " +
				"(productId, productName) VALUES (?, ?)" ;
		getJdbcTemplate().update(sql, new Object[]{
				product.getProductId(), product.getProductName()
		});
		
	}
}